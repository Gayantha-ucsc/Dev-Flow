<?php

return [
    'host'     => 'localhost',
    'dbname'   => 'devflow',
    'username' => 'root',
    'password' => '',      // XAMPP default MySQL has no root password
    'charset'  => 'utf8mb4',
];